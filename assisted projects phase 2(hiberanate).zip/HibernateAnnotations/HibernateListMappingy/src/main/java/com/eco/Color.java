package com.eco;

public class Color {

}
