package com.eco;

public class HibernateUtil {

}
