package com.eco;

public class ScreenSizes {

}
