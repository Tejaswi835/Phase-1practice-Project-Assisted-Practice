package com.example.main;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.example.pojo.employee;

/*
StandardServiceRegistry 
Metadata
SessionFactory
Session
Transaction
Close the connections

 * */
public class EmpMain {
public static void main(String[] args) {
	//SSR is used to map the config file and execute it .
	StandardServiceRegistry  ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();	
	//Metadata of the xml file is read by this object
	Metadata md=new MetadataSources(ssr).getMetadataBuilder().build();
	//session-factory- db
	SessionFactory sf=md.getSessionFactoryBuilder().build();
	//all the crud operations need to be done in Session 
	Session s=sf.openSession();
	//Transaction- perform sql operations and commit it permenantly on the db
	Transaction t=s.beginTransaction();
	Scanner sc=new Scanner(System.in);
	employee e=new employee();
	System.out.println("enter the eid");
	e.setEid(sc.nextInt());
	System.out.println("enter the ename");
	e.setEmpname(sc.next());
	System.out.println("enter the email");
	e.setEmpemail(sc.next());
	System.out.println("enter the salary");
	e.setSalary(sc.nextDouble());
	s.save(e);  //insert
	t.commit();
	s.close();
	sf.close();
	
	
}
}
