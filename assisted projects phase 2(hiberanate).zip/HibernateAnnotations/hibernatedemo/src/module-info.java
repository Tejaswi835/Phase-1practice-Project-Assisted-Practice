/**
 * 
 */
/**
 * @author tejaswi
 *
 */
module hibernatedemo {
	requires java.persistence;
	requires org.hibernate.orm.core;
}